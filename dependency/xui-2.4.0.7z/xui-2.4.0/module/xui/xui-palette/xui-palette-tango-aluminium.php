<?php
/*
//
// Copyright (c) 2018-2019 Grigore Stefan <g_stefan@yahoo.com>
// Created by Grigore Stefan <g_stefan@yahoo.com>
//
// MIT License (MIT) <http://opensource.org/licenses/MIT>
//
*/

defined("XYO_CLOUD") or die("Access is denied");

$this->palette["tango-aluminium-1"]="#EEEEEC";
$this->palette["tango-aluminium-2"]="#D3D7CF";
$this->palette["tango-aluminium-3"]="#BABDB6";
$this->palette["tango-aluminium-4"]="#888A85";
$this->palette["tango-aluminium-5"]="#555753";
$this->palette["tango-aluminium-6"]="#2E3436";

