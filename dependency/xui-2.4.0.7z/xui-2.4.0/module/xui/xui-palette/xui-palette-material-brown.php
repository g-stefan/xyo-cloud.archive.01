<?php
/*
//
// Copyright (c) 2018-2019 Grigore Stefan <g_stefan@yahoo.com>
// Created by Grigore Stefan <g_stefan@yahoo.com>
//
// MIT License (MIT) <http://opensource.org/licenses/MIT>
//
*/

defined("XYO_CLOUD") or die("Access is denied");


$this->palette["material-brown-50"]="#EFEBE9";
$this->palette["material-brown-100"]="#D7CCC8";
$this->palette["material-brown-200"]="#BCAAA4";
$this->palette["material-brown-300"]="#A1887F";
$this->palette["material-brown-400"]="#8D6E63";
$this->palette["material-brown-500"]="#795548";
$this->palette["material-brown-600"]="#6D4C41";
$this->palette["material-brown-700"]="#5D4037";
$this->palette["material-brown-800"]="#4E342E";
$this->palette["material-brown-900"]="#3E2723";
