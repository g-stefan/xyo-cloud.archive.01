/*
//
// Copyright (c) 2018-2019 Grigore Stefan <g_stefan@yahoo.com>
// Created by Grigore Stefan <g_stefan@yahoo.com>
//
// MIT License (MIT) <http://opensource.org/licenses/MIT>
//
*/

<style>

.xui.text{	
	font-family: "Roboto", sans-serif;
	box-sizing: border-box;
}

</style>

<?php $this->includeCSS("xui-text","xui-text-size-h20x40"); ?>
<?php $this->includeCSS("xui-text","xui-text-size-h24x40"); ?>
<?php $this->includeCSS("xui-text","xui-text-label-40"); ?>