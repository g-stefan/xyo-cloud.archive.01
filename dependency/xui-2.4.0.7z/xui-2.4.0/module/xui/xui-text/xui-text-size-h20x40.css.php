/*
//
// Copyright (c) 2018-2019 Grigore Stefan <g_stefan@yahoo.com>
// Created by Grigore Stefan <g_stefan@yahoo.com>
//
// MIT License (MIT) <http://opensource.org/licenses/MIT>
//
*/

<style>

.xui.text.-size-h20x40{
	position: relative;
	width: auto;
	height: 40px;	
	padding-left: 10px;
	padding-top: 10px;
	padding-bottom: 10px;
	padding-right: 10px;
	overflow: hidden;
	font-size: 18px;
	line-height: 20px;

	font-family: "Roboto", sans-serif;
	box-sizing: border-box;
}

</style>
