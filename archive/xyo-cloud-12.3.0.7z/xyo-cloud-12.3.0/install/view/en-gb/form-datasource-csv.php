<?php
//
// Copyright (c) 2018-2019 Grigore Stefan <g_stefan@yahoo.com>
// Created by Grigore Stefan <g_stefan@yahoo.com>
//
// MIT License (MIT) <http://opensource.org/licenses/MIT>
//

defined("XYO_CLOUD") or die("Access is denied");

?>
<p>
CSV Data Source Layer is based on csv files,
stored in repository.
</p>
<p>
Suitable for small sites/applications or
debug your applications.
</p>
<p>
You can change location from
config/config.ds.db.php .
</p>
<br />
<div class="xui alert -warning">
Warning: If you store sesitive information is
advised to change the location outside of website.
</div>
<br />