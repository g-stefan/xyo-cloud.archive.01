XYO Cloud
=========

MVC Framework for PHP

- Object based 
- Multiple database backends (Php, Csv, MySql, Postgresql, SQlite3)
- Active Record Pattern
- ACL based system
- Module management and auhorization
- Quantum database connector (Active Record Pattern based query with fields in separate tables/databases or another quantum query)
- jQuery
- XUI


