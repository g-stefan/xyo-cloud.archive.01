<?php
//
// Copyright (c) 2018-2019 Grigore Stefan <g_stefan@yahoo.com>
// Created by Grigore Stefan <g_stefan@yahoo.com>
//
// MIT License (MIT) <http://opensource.org/licenses/MIT>
//

defined("XYO_CLOUD") or die("Access is denied");

?>
<p>
Baza de date CSV este realizata folosind fisiere csv,
stocate in repository.
</p>
<p>
Se potriveste pentru siteuri/aplicatii mici sau pentru
a rezlova defectele in aplicatii.
</p>
<p>
Poti schimba locatia editand fisierul
config/config.ds.db.php .
</p>
<br />
<div class="xui alert -warning">
Avertisment: Daca salvezi informatii cu caracter
confidential sugestia este ca locatia sa fie in
afara website-ului.
</div>
<br />