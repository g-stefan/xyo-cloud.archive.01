<?php
//
// Copyright (c) 2018-2019 Grigore Stefan <g_stefan@yahoo.com>
// Created by Grigore Stefan <g_stefan@yahoo.com>
//
// MIT License (MIT) <http://opensource.org/licenses/MIT>
//

defined("XYO_CLOUD") or die("Access is denied");

?>
<p>
XYO Data Source Layer is based on php like csv files,
stored in repository.This is to protect files from
unauthorized access.
</p>
<p>
Suitable for small sites/applications or
debug your applications.
</p>
<p>
You can change location from
config/config.ds.db.php .
</p>
